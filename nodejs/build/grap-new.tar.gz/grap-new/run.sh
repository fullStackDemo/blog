

echo "run_port=$1"
npm config set grap-new:port 9001
node server.js