

echo "chat_run_port=$1"
npm config set grap-new:port $1
yarn dev